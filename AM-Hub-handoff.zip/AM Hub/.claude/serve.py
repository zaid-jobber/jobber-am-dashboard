import http.server, socketserver, functools, os

ROOT = "/Users/zaidfarooqui/Documents/AM Hub"
os.chdir(ROOT)

class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=ROOT, **k)
    def translate_path(self, path):
        if path == "/" or path == "":
            path = "/concept-hub.html"
        return super().translate_path(path)

with socketserver.TCPServer(("127.0.0.1", 4321), H) as httpd:
    print("serving on 4321")
    httpd.serve_forever()
